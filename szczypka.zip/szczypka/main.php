<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strona Główna</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="grid-container">
    <header>
        <h1>Witaj w bazie 2pb</h1>
    </header>
    <div id="item4">
        
    </div id="item4">
    <main>
        <div id="ul">
            <button><a href="modyfikowanie.php">dodawanie i usuwanie uczniow</a></button>
            <button> <a href="dodawanie_klas.php">dodawnie klas</a></button>
            <button><a href="wszyscy.php"> wszyscy uczniowie</a></button>
        </div>
        
     
    </main>
    <div id="rightBanner">
    </div>
    <div id="item7"></div>
    <footer>
    </footer>
    <div id="item9"></div>
</div>
</body>
</html>